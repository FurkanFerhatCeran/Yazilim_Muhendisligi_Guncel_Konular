"""
Question Generator
RAG assembly with LLM generation and validation
"""
import logging
from typing import Dict, Any, Optional, List

from config import MAX_RETRIES, DEFAULT_TOP_K
from llm_client import get_llm_client, GeminiClient
from retrieval import retrieve, format_examples_for_prompt
from prompt_templates import build_generation_prompt, build_correction_prompt
from utils import safe_json_parse, validate_output, ensure_metadata_defaults

logger = logging.getLogger(__name__)


class QuestionGenerator:
    """RAG-based question generator"""
    
    def __init__(self, llm_client: Optional[GeminiClient] = None):
        self.llm_client = llm_client or get_llm_client()
        self.max_retries = MAX_RETRIES
    
    def generate(
        self,
        zorluk: str,
        unite: Optional[str] = None,
        konu_alt_basligi: Optional[str] = None,
        soru_tipi: Optional[str] = None,
        use_image: bool = False,
        top_k: int = DEFAULT_TOP_K
    ) -> Dict[str, Any]:
        """
        Generate a new question using RAG
        
        Args:
            zorluk: Difficulty level (kolay, orta, zor)
            unite: Optional unit filter
            konu_alt_basligi: Optional sub-topic filter
            soru_tipi: Optional question type filter
            use_image: If True, prefer examples with images
            top_k: Number of examples to retrieve
            
        Returns:
            Generated question dict
        """
        logger.info(f"Generating question: zorluk={zorluk}, konu={konu_alt_basligi}")
        
        # Step 1: Retrieve similar examples
        examples = retrieve(
            zorluk=zorluk,
            unite=unite,
            konu_alt_basligi=konu_alt_basligi,
            soru_tipi=soru_tipi,
            use_image=use_image,
            top_k=top_k
        )
        
        if not examples:
            logger.warning("No examples retrieved, generating without context")
        
        # Step 2: Format examples for prompt
        examples_text = format_examples_for_prompt(examples)
        
        # Step 3: Build prompt
        prompt = build_generation_prompt(
            zorluk=zorluk,
            examples_text=examples_text
        )
        
        # Step 4: Generate with retries
        result = self._generate_with_retries(prompt, zorluk)
        
        return result
    
    def _generate_with_retries(
        self, 
        prompt: str, 
        zorluk: str
    ) -> Dict[str, Any]:
        """
        Generate question with retry logic
        
        Args:
            prompt: The generation prompt
            zorluk: Difficulty level for metadata defaults
            
        Returns:
            Validated question dict
        """
        last_error = None
        last_response = None
        
        for attempt in range(self.max_retries + 1):
            try:
                if attempt == 0:
                    # First attempt with original prompt
                    response = self.llm_client.generate(prompt)
                else:
                    # Retry with correction prompt
                    correction_prompt = build_correction_prompt(
                        original_response=last_response or "",
                        error_message=last_error or "Unknown error"
                    )
                    full_prompt = prompt + "\n\n" + correction_prompt
                    response = self.llm_client.generate(full_prompt)
                
                last_response = response
                
                # Debug: Log the actual response
                logger.info(f"LLM Response (first 500 chars): {response[:500] if response else 'EMPTY'}")
                
                # Parse JSON
                parsed, parse_error = safe_json_parse(response)
                
                if parse_error:
                    logger.warning(f"Attempt {attempt + 1}: Parse error - {parse_error}")
                    last_error = parse_error
                    continue
                
                # Validate output
                is_valid, validation_errors = validate_output(parsed)
                
                if not is_valid:
                    logger.warning(f"Attempt {attempt + 1}: Validation errors - {validation_errors}")
                    last_error = "; ".join(validation_errors)
                    continue
                
                # Success! Apply defaults and return
                result = ensure_metadata_defaults(parsed, zorluk)
                logger.info(f"Question generated successfully on attempt {attempt + 1}")
                return result
                
            except Exception as e:
                logger.error(f"Attempt {attempt + 1}: Exception - {e}")
                last_error = str(e)
                continue
        
        # All retries failed, return error response
        logger.error(f"All {self.max_retries + 1} attempts failed")
        return self._create_error_response(zorluk, last_error)
    
    def _create_error_response(self, zorluk: str, error: str) -> Dict[str, Any]:
        """Create an error response when generation fails"""
        return {
            "error": True,
            "message": f"Soru üretimi başarısız oldu: {error}",
            "soru": "",
            "secenekler": {"A": "", "B": "", "C": "", "D": ""},
            "dogru_cevap": "A",
            "aciklama": "",
            "metadata": {
                "unite": "Veri Analizi",
                "zorluk": zorluk,
                "generation_error": error
            }
        }


# Singleton instance
_generator_instance: Optional[QuestionGenerator] = None


def get_generator() -> QuestionGenerator:
    """Get or create the generator singleton"""
    global _generator_instance
    if _generator_instance is None:
        _generator_instance = QuestionGenerator()
    return _generator_instance


def generate_question(
    zorluk: str,
    unite: Optional[str] = None,
    konu_alt_basligi: Optional[str] = None,
    soru_tipi: Optional[str] = None,
    use_image: bool = False,
    top_k: int = DEFAULT_TOP_K
) -> Dict[str, Any]:
    """
    Convenience function to generate a question
    
    Args:
        zorluk: Difficulty level (kolay, orta, zor)
        unite: Optional unit filter
        konu_alt_basligi: Optional sub-topic filter
        soru_tipi: Optional question type filter
        use_image: If True, prefer examples with images
        top_k: Number of examples to retrieve
        
    Returns:
        Generated question dict
    """
    generator = get_generator()
    return generator.generate(
        zorluk=zorluk,
        unite=unite,
        konu_alt_basligi=konu_alt_basligi,
        soru_tipi=soru_tipi,
        use_image=use_image,
        top_k=top_k
    )
