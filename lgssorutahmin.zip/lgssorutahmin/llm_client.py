"""
Gemini LLM Client
Provides text generation using Google Gemini models
"""
import logging
import json
import re
from typing import Optional, Dict, Any
import google.generativeai as genai

from config import GEMINI_API_KEY, GEMINI_MODEL, LLM_TEMPERATURE, LLM_MAX_TOKENS

logger = logging.getLogger(__name__)


class GeminiClient:
    """LLM client using Google Gemini generative models"""
    
    def __init__(
        self, 
        api_key: Optional[str] = None, 
        model: Optional[str] = None,
        temperature: float = LLM_TEMPERATURE,
        max_tokens: int = LLM_MAX_TOKENS
    ):
        self.api_key = api_key or GEMINI_API_KEY
        self.model_name = model or GEMINI_MODEL
        self.temperature = temperature
        self.max_tokens = max_tokens
        
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY is required. Set it in environment or .env file.")
        
        genai.configure(api_key=self.api_key)
        
        # Configure generation settings
        self.generation_config = genai.GenerationConfig(
            temperature=self.temperature,
            max_output_tokens=self.max_tokens
        )
        
        # Initialize model
        self.model = genai.GenerativeModel(
            model_name=self.model_name,
            generation_config=self.generation_config
        )
        
        logger.info(f"GeminiClient initialized with model: {self.model_name}")
    
    def generate(self, prompt: str) -> str:
        """
        Generate text response from prompt
        
        Args:
            prompt: Input prompt for generation
            
        Returns:
            Generated text response
        """
        try:
            response = self.model.generate_content(prompt)
            
            if response.text:
                return response.text
            else:
                logger.warning("Empty response from Gemini")
                return ""
                
        except Exception as e:
            logger.error(f"Generation error: {e}")
            raise
    
    def generate_json(self, prompt: str) -> Optional[Dict[str, Any]]:
        """
        Generate and parse JSON response
        
        Args:
            prompt: Input prompt expecting JSON output
            
        Returns:
            Parsed JSON dict or None if parsing fails
        """
        try:
            response_text = self.generate(prompt)
            
            # Try to extract JSON from response
            json_str = self._extract_json(response_text)
            
            if json_str:
                return json.loads(json_str)
            else:
                logger.warning("Could not extract JSON from response")
                return None
                
        except json.JSONDecodeError as e:
            logger.error(f"JSON parsing error: {e}")
            return None
        except Exception as e:
            logger.error(f"Generation error: {e}")
            raise
    
    def _extract_json(self, text: str) -> Optional[str]:
        """
        Extract JSON from text response
        Handles cases where JSON is wrapped in markdown code blocks
        """
        if not text:
            return None
        
        # Remove markdown code blocks if present
        text = text.strip()
        
        # Try to find JSON in code blocks
        code_block_pattern = r'```(?:json)?\s*([\s\S]*?)\s*```'
        match = re.search(code_block_pattern, text)
        if match:
            return match.group(1).strip()
        
        # Try to find raw JSON object
        json_pattern = r'\{[\s\S]*\}'
        match = re.search(json_pattern, text)
        if match:
            return match.group(0)
        
        return text


# Singleton instance for dependency injection
_llm_instance: Optional[GeminiClient] = None


def get_llm_client() -> GeminiClient:
    """Get or create the LLM client singleton"""
    global _llm_instance
    if _llm_instance is None:
        _llm_instance = GeminiClient()
    return _llm_instance
