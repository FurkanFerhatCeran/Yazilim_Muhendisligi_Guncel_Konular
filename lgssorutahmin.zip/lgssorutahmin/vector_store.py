"""
Vector Store using ChromaDB
Handles document indexing and retrieval
"""
import logging
from typing import List, Dict, Any, Optional
from pathlib import Path
import chromadb
from chromadb.config import Settings

from config import CHROMA_PERSIST_DIR
from embedder import get_embedder, GeminiEmbedder
from data_loader import load_dataset, get_documents_for_indexing

logger = logging.getLogger(__name__)

COLLECTION_NAME = "lgs_veri_analizi"


class VectorStore:
    """ChromaDB vector store for LGS questions"""
    
    def __init__(
        self, 
        persist_dir: Optional[Path] = None,
        embedder: Optional[GeminiEmbedder] = None
    ):
        self.persist_dir = persist_dir or CHROMA_PERSIST_DIR
        self.embedder = embedder
        
        # Initialize ChromaDB client with persistence
        self.client = chromadb.PersistentClient(
            path=str(self.persist_dir),
            settings=Settings(anonymized_telemetry=False)
        )
        
        self.collection = None
        logger.info(f"VectorStore initialized with persist_dir: {self.persist_dir}")
    
    def _get_embedder(self) -> GeminiEmbedder:
        """Get embedder instance"""
        if self.embedder is None:
            self.embedder = get_embedder()
        return self.embedder
    
    def build_index(self, force_rebuild: bool = False) -> None:
        """
        Build the vector index from dataset
        
        Args:
            force_rebuild: If True, delete existing collection and rebuild
        """
        # Check if collection exists
        existing_collections = [c.name for c in self.client.list_collections()]
        
        if COLLECTION_NAME in existing_collections:
            if force_rebuild:
                logger.info(f"Deleting existing collection: {COLLECTION_NAME}")
                self.client.delete_collection(COLLECTION_NAME)
            else:
                logger.info(f"Collection {COLLECTION_NAME} already exists. Use force_rebuild=True to rebuild.")
                self.collection = self.client.get_collection(COLLECTION_NAME)
                return
        
        # Create collection
        self.collection = self.client.create_collection(
            name=COLLECTION_NAME,
            metadata={"description": "LGS Veri Analizi question embeddings"}
        )
        
        # Load and prepare documents
        ids, documents, metadatas = get_documents_for_indexing()
        
        # Generate embeddings
        logger.info(f"Generating embeddings for {len(documents)} documents...")
        embedder = self._get_embedder()
        embeddings = embedder.embed_batch(documents)
        
        # Add to collection in batches
        batch_size = 100
        for i in range(0, len(ids), batch_size):
            end_idx = min(i + batch_size, len(ids))
            
            self.collection.add(
                ids=ids[i:end_idx],
                embeddings=embeddings[i:end_idx],
                documents=documents[i:end_idx],
                metadatas=metadatas[i:end_idx]
            )
            
            logger.info(f"Added batch {i//batch_size + 1}, documents {i+1}-{end_idx}")
        
        logger.info(f"Index built successfully with {len(ids)} documents")
    
    def load_index(self) -> bool:
        """
        Load existing index
        
        Returns:
            True if collection was loaded, False if it doesn't exist
        """
        try:
            self.collection = self.client.get_collection(COLLECTION_NAME)
            count = self.collection.count()
            logger.info(f"Loaded collection {COLLECTION_NAME} with {count} documents")
            return True
        except Exception as e:
            logger.warning(f"Could not load collection: {e}")
            return False
    
    def query(
        self, 
        query_text: str,
        n_results: int = 8,
        where: Optional[Dict[str, Any]] = None,
        where_document: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Query the vector store
        
        Args:
            query_text: Query text to search for
            n_results: Number of results to return
            where: Metadata filter conditions
            where_document: Document content filter conditions
            
        Returns:
            Query results with ids, documents, metadatas, distances
        """
        if self.collection is None:
            if not self.load_index():
                raise ValueError("No index available. Run build_index() first.")
        
        # Generate query embedding
        embedder = self._get_embedder()
        query_embedding = embedder.embed_query(query_text)
        
        # Build query kwargs
        query_kwargs = {
            "query_embeddings": [query_embedding],
            "n_results": n_results,
            "include": ["documents", "metadatas", "distances"]
        }
        
        if where:
            query_kwargs["where"] = where
        
        if where_document:
            query_kwargs["where_document"] = where_document
        
        results = self.collection.query(**query_kwargs)
        
        return results
    
    def get_collection_count(self) -> int:
        """Get number of documents in collection"""
        if self.collection is None:
            self.load_index()
        
        if self.collection:
            return self.collection.count()
        return 0


# Singleton instance
_vector_store_instance: Optional[VectorStore] = None


def get_vector_store() -> VectorStore:
    """Get or create the vector store singleton"""
    global _vector_store_instance
    if _vector_store_instance is None:
        _vector_store_instance = VectorStore()
    return _vector_store_instance


if __name__ == "__main__":
    # CLI for building index
    import sys
    logging.basicConfig(level=logging.INFO)
    
    vs = VectorStore()
    
    if len(sys.argv) > 1 and sys.argv[1] == "--rebuild":
        vs.build_index(force_rebuild=True)
    else:
        vs.build_index(force_rebuild=False)
