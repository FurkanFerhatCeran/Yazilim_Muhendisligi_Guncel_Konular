"""
Data Loader for LGS Dataset
Loads and normalizes the CSV dataset for RAG indexing
"""
import logging
from typing import List, Dict, Any, Optional
from pathlib import Path
import pandas as pd

from config import DATASET_PATH, ZORLUK_MAPPING, ALLOWED_UNITE

logger = logging.getLogger(__name__)


def parse_list_field(value: str) -> List[str]:
    """
    Parse pipe-separated list fields like on_bilgi and matematiksel_beceriler
    
    Args:
        value: String with pipe-separated values
        
    Returns:
        List of individual values
    """
    if pd.isna(value) or not value:
        return []
    
    return [item.strip() for item in str(value).split("|") if item.strip()]


def build_document_text(row: pd.Series) -> str:
    """
    Build the text document for embedding from a row
    
    Format: baglam + kazanım + konu_alt_basligi + soru_tipi + veri_yapisi + on_bilgi + matematiksel_beceriler
    """
    parts = []
    
    # Main content fields
    if pd.notna(row.get('baglam')):
        parts.append(str(row['baglam']))
    
    if pd.notna(row.get('kazanım')):
        parts.append(str(row['kazanım']))
    
    if pd.notna(row.get('konu_alt_basligi')):
        parts.append(str(row['konu_alt_basligi']))
    
    if pd.notna(row.get('soru_tipi')):
        parts.append(str(row['soru_tipi']))
    
    if pd.notna(row.get('veri_yapisi')):
        parts.append(str(row['veri_yapisi']))
    
    if pd.notna(row.get('on_bilgi')):
        parts.append(str(row['on_bilgi']))
    
    if pd.notna(row.get('matematiksel_beceriler')):
        parts.append(str(row['matematiksel_beceriler']))
    
    return "\n".join(parts)


def map_zorluk_to_category(zorluk_value: int) -> str:
    """Map numeric zorluk (1-5) to category (kolay/orta/zor)"""
    return ZORLUK_MAPPING.get(int(zorluk_value), "orta")


def load_dataset(path: Optional[Path] = None) -> pd.DataFrame:
    """
    Load and process the LGS dataset
    
    Args:
        path: Path to CSV file (defaults to DATASET_PATH from config)
        
    Returns:
        Processed DataFrame with all columns
    """
    path = path or DATASET_PATH
    
    logger.info(f"Loading dataset from: {path}")
    
    # Read CSV
    df = pd.read_csv(path, encoding='utf-8')
    
    logger.info(f"Loaded {len(df)} rows with columns: {list(df.columns)}")
    
    # Filter to only Veri Analizi (domain enforcement)
    if 'unite' in df.columns:
        df = df[df['unite'] == ALLOWED_UNITE].copy()
        logger.info(f"Filtered to {len(df)} rows for unite='{ALLOWED_UNITE}'")
    
    # Add zorluk category mapping
    if 'zorluk' in df.columns:
        df['zorluk_kategori'] = df['zorluk'].apply(map_zorluk_to_category)
    
    # Parse list fields
    if 'on_bilgi' in df.columns:
        df['on_bilgi_list'] = df['on_bilgi'].apply(parse_list_field)
    
    if 'matematiksel_beceriler' in df.columns:
        df['matematiksel_beceriler_list'] = df['matematiksel_beceriler'].apply(parse_list_field)
    
    # Build document text for embedding
    df['document_text'] = df.apply(build_document_text, axis=1)
    
    # Ensure image_path handling
    if 'image_path' in df.columns:
        df['has_image'] = df['image_path'].notna() & (df['image_path'] != '')
    else:
        df['has_image'] = False
    
    return df


def row_to_metadata(row: pd.Series) -> Dict[str, Any]:
    """
    Convert a DataFrame row to metadata dict for ChromaDB
    
    Args:
        row: Pandas Series representing a row
        
    Returns:
        Dict with all metadata fields
    """
    metadata = {
        'id': str(row.get('id', '')),
        'unite': str(row.get('unite', '')),
        'konu_alt_basligi': str(row.get('konu_alt_basligi', '')),
        'kazanim': str(row.get('kazanım', '')),
        'soru_tipi': str(row.get('soru_tipi', '')),
        'bloom': str(row.get('bloom', '')),
        'zorluk': int(row.get('zorluk', 3)),
        'zorluk_kategori': str(row.get('zorluk_kategori', 'orta')),
        'gorsel_turu': str(row.get('gorsel_turu', '')),
        'veri_yapisi': str(row.get('veri_yapisi', '')),
        'on_bilgi': str(row.get('on_bilgi', '')),
        'matematiksel_beceriler': str(row.get('matematiksel_beceriler', '')),
        'baglam': str(row.get('baglam', '')),
        'kaynak_yil': int(row.get('kaynak_yil', 0)) if pd.notna(row.get('kaynak_yil')) else 0,
        'dogru_cevap': str(row.get('dogru_cevap', '')),
        'image_path': str(row.get('image_path', '')) if pd.notna(row.get('image_path')) else '',
        'bloom_ordinal': int(row.get('bloom_ordinal', 0)) if pd.notna(row.get('bloom_ordinal')) else 0,
        'gorsel_karmasiklik': int(row.get('gorsel_karmaşıklık', 0)) if pd.notna(row.get('gorsel_karmaşıklık')) else 0,
        'veri_yapisi_karmasiklik': int(row.get('veri_yapisi_karmaşıklık', 0)) if pd.notna(row.get('veri_yapisi_karmaşıklık')) else 0,
        'on_bilgi_sayisi': int(row.get('on_bilgi_sayisi', 0)) if pd.notna(row.get('on_bilgi_sayisi')) else 0,
        'mat_beceri_sayisi': int(row.get('mat_beceri_sayisi', 0)) if pd.notna(row.get('mat_beceri_sayisi')) else 0,
        'has_image': bool(row.get('has_image', False))
    }
    
    return metadata


def get_documents_for_indexing(df: Optional[pd.DataFrame] = None) -> tuple:
    """
    Prepare documents for ChromaDB indexing
    
    Args:
        df: DataFrame to process (loads from config if None)
        
    Returns:
        Tuple of (ids, documents, metadatas)
    """
    if df is None:
        df = load_dataset()
    
    ids = []
    documents = []
    metadatas = []
    
    for idx, row in df.iterrows():
        doc_id = str(row.get('id', f'doc_{idx}'))
        doc_text = row.get('document_text', '')
        metadata = row_to_metadata(row)
        
        ids.append(doc_id)
        documents.append(doc_text)
        metadatas.append(metadata)
    
    logger.info(f"Prepared {len(ids)} documents for indexing")
    
    return ids, documents, metadatas
