"""Test zor zorluk soru üretimi - Detaylı debug"""
import os
import sys
from dotenv import load_dotenv
load_dotenv()

# Setup
sys.path.insert(0, '.')
from generator import generate_question

print("Testing ZOR difficulty...")
print("=" * 50)

try:
    result = generate_question(zorluk="zor")
    
    if result.get("error"):
        print("ERROR:", result.get("message"))
    else:
        print("SUCCESS!")
        print("Soru:", result.get("soru", "")[:100])
        print("Grafik verisi:", result.get("grafik_verisi"))
        
except Exception as e:
    print(f"Exception: {e}")
    import traceback
    traceback.print_exc()
