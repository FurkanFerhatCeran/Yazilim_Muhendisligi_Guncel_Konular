"""Test orta zorluk soru üretimi"""
import google.generativeai as genai
import os
from dotenv import load_dotenv
load_dotenv()

api_key = os.getenv('GEMINI_API_KEY')
genai.configure(api_key=api_key)

model = genai.GenerativeModel('gemini-2.5-flash', generation_config={'max_output_tokens': 4096})

prompt = """Veri Analizi konusunda ORTA zorlukta bir LGS matematik sorusu uret.
JSON formatinda yanit ver:
{
  "soru": "...",
  "secenekler": {"A": "...", "B": "...", "C": "...", "D": "..."},
  "dogru_cevap": "A",
  "aciklama": "...",
  "grafik_verisi": [],
  "metadata": {"unite": "Veri Analizi", "zorluk": "orta"}
}"""

response = model.generate_content(prompt)
print('Response length:', len(response.text) if response.text else 0)
print('---')
print(response.text if response.text else 'EMPTY')
