"""
Gemini Embedding Client
Provides text embeddings using Google's text-embedding model
"""
import logging
from typing import List, Optional
from functools import lru_cache
import google.generativeai as genai

from config import GEMINI_API_KEY, GEMINI_EMBED_MODEL, EMBEDDING_BATCH_SIZE

logger = logging.getLogger(__name__)


class GeminiEmbedder:
    """Embedder using Google Gemini text-embedding model"""
    
    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        self.api_key = api_key or GEMINI_API_KEY
        self.model = model or GEMINI_EMBED_MODEL
        self._cache = {}
        
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY is required. Set it in environment or .env file.")
        
        genai.configure(api_key=self.api_key)
        logger.info(f"GeminiEmbedder initialized with model: {self.model}")
    
    def embed(self, text: str) -> List[float]:
        """
        Generate embedding for a single text
        
        Args:
            text: Input text to embed
            
        Returns:
            List of floats representing the embedding vector
        """
        # Check cache first
        cache_key = hash(text)
        if cache_key in self._cache:
            return self._cache[cache_key]
        
        try:
            result = genai.embed_content(
                model=f"models/{self.model}",
                content=text,
                task_type="retrieval_document"
            )
            embedding = result['embedding']
            
            # Cache the result
            self._cache[cache_key] = embedding
            
            return embedding
            
        except Exception as e:
            logger.error(f"Embedding error: {e}")
            raise
    
    def embed_query(self, text: str) -> List[float]:
        """
        Generate embedding for a query (uses retrieval_query task type)
        
        Args:
            text: Query text to embed
            
        Returns:
            List of floats representing the embedding vector
        """
        try:
            result = genai.embed_content(
                model=f"models/{self.model}",
                content=text,
                task_type="retrieval_query"
            )
            return result['embedding']
            
        except Exception as e:
            logger.error(f"Query embedding error: {e}")
            raise
    
    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for multiple texts with batching
        
        Args:
            texts: List of texts to embed
            
        Returns:
            List of embedding vectors
        """
        embeddings = []
        
        for i in range(0, len(texts), EMBEDDING_BATCH_SIZE):
            batch = texts[i:i + EMBEDDING_BATCH_SIZE]
            batch_embeddings = []
            
            for text in batch:
                embedding = self.embed(text)
                batch_embeddings.append(embedding)
            
            embeddings.extend(batch_embeddings)
            logger.info(f"Embedded batch {i//EMBEDDING_BATCH_SIZE + 1}, total: {len(embeddings)}/{len(texts)}")
        
        return embeddings
    
    def clear_cache(self):
        """Clear the embedding cache"""
        self._cache.clear()
        logger.info("Embedding cache cleared")


# Singleton instance for dependency injection
_embedder_instance: Optional[GeminiEmbedder] = None


def get_embedder() -> GeminiEmbedder:
    """Get or create the embedder singleton"""
    global _embedder_instance
    if _embedder_instance is None:
        _embedder_instance = GeminiEmbedder()
    return _embedder_instance
