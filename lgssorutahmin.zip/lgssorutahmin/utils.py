"""
Utility Functions
JSON schema validation, safe parsing, and logging setup
"""
import logging
import json
from typing import Dict, Any, Optional, List, Tuple

# Configure logging
def setup_logging(level: int = logging.INFO) -> None:
    """Setup logging configuration"""
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

# JSON Schema for output validation
QUESTION_SCHEMA = {
    "type": "object",
    "required": ["soru", "secenekler", "dogru_cevap", "aciklama", "metadata"],
    "properties": {
        "soru": {"type": "string", "minLength": 10},
        "secenekler": {
            "type": "object",
            "required": ["A", "B", "C", "D"],
            "properties": {
                "A": {"type": "string"},
                "B": {"type": "string"},
                "C": {"type": "string"},
                "D": {"type": "string"}
            },
            "additionalProperties": False
        },
        "dogru_cevap": {"type": "string", "enum": ["A", "B", "C", "D"]},
        "aciklama": {"type": "string"},
        "metadata": {
            "type": "object",
            "required": ["unite", "zorluk"],
            "properties": {
                "unite": {"type": "string"},
                "konu_alt_basligi": {"type": "string"},
                "kazanim": {"type": "string"},
                "soru_tipi": {"type": "string"},
                "bloom": {"type": "string"},
                "bloom_ordinal": {"type": "integer"},
                "zorluk": {"type": "string"},
                "gorsel_turu": {"type": "string"},
                "veri_yapisi": {"type": "string"},
                "on_bilgi": {"type": "array", "items": {"type": "string"}},
                "matematiksel_beceriler": {"type": "array", "items": {"type": "string"}},
                "kaynak_yil": {"type": "integer"},
                "image_path": {"type": ["string", "null"]}
            }
        }
    }
}


def safe_json_parse(text: str) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """
    Safely parse JSON from text
    
    Args:
        text: Text containing JSON
        
    Returns:
        Tuple of (parsed_dict, error_message)
    """
    if not text:
        return None, "Empty response"
    
    # Clean up the text
    text = text.strip()
    
    # Remove markdown code blocks if present
    import re
    
    # Try to extract JSON from markdown code block
    code_block_pattern = r'```(?:json)?\s*([\s\S]*?)\s*```'
    match = re.search(code_block_pattern, text)
    if match:
        text = match.group(1).strip()
    
    # If still starts with ```, manually strip
    if text.startswith("```"):
        lines = text.split("\n")
        if lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines)
    
    # Try to find JSON object by matching braces
    start_idx = text.find("{")
    if start_idx == -1:
        return None, "No JSON object found in response"
    
    # Count braces to find the matching closing brace
    brace_count = 0
    end_idx = -1
    in_string = False
    escape_next = False
    
    for i, char in enumerate(text[start_idx:], start=start_idx):
        if escape_next:
            escape_next = False
            continue
        if char == '\\':
            escape_next = True
            continue
        if char == '"' and not escape_next:
            in_string = not in_string
            continue
        if in_string:
            continue
        if char == '{':
            brace_count += 1
        elif char == '}':
            brace_count -= 1
            if brace_count == 0:
                end_idx = i + 1
                break
    
    if end_idx == -1:
        # Try rfind as fallback
        end_idx = text.rfind("}") + 1
        if end_idx == 0:
            return None, "No closing brace found in JSON"
    
    json_str = text[start_idx:end_idx]
    
    try:
        parsed = json.loads(json_str)
        return parsed, None
    except json.JSONDecodeError as e:
        return None, f"JSON parse error: {str(e)}"


def validate_output(data: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """
    Validate the generated question against schema
    
    Args:
        data: Parsed JSON data
        
    Returns:
        Tuple of (is_valid, list of error messages)
    """
    errors = []
    
    # Check required top-level fields
    required_fields = ["soru", "secenekler", "dogru_cevap", "aciklama", "metadata"]
    for field in required_fields:
        if field not in data:
            errors.append(f"Missing required field: {field}")
    
    if errors:
        return False, errors
    
    # Validate soru
    if not isinstance(data["soru"], str) or len(data["soru"]) < 10:
        errors.append("'soru' must be a non-empty string with at least 10 characters")
    
    # Validate secenekler
    secenekler = data.get("secenekler", {})
    if not isinstance(secenekler, dict):
        errors.append("'secenekler' must be an object")
    else:
        for key in ["A", "B", "C", "D"]:
            if key not in secenekler:
                errors.append(f"Missing option '{key}' in secenekler")
            elif not isinstance(secenekler[key], str):
                errors.append(f"Option '{key}' must be a string")
    
    # Validate dogru_cevap
    dogru_cevap = data.get("dogru_cevap", "")
    if dogru_cevap not in ["A", "B", "C", "D"]:
        errors.append(f"'dogru_cevap' must be A, B, C, or D, got: {dogru_cevap}")
    
    # Check that dogru_cevap matches an option
    if dogru_cevap in secenekler:
        if not secenekler[dogru_cevap]:
            errors.append(f"Correct answer option '{dogru_cevap}' is empty")
    
    # Validate metadata
    metadata = data.get("metadata", {})
    if not isinstance(metadata, dict):
        errors.append("'metadata' must be an object")
    else:
        if "unite" not in metadata:
            errors.append("Missing 'unite' in metadata")
        if "zorluk" not in metadata:
            errors.append("Missing 'zorluk' in metadata")
    
    return len(errors) == 0, errors


def ensure_metadata_defaults(data: Dict[str, Any], zorluk: str) -> Dict[str, Any]:
    """
    Ensure metadata has all expected fields with defaults
    
    Args:
        data: The question data
        zorluk: The requested difficulty
        
    Returns:
        Data with complete metadata
    """
    if "metadata" not in data:
        data["metadata"] = {}
    
    # Ensure grafik_verisi exists and is a list
    if "grafik_verisi" not in data or data["grafik_verisi"] is None:
        data["grafik_verisi"] = []
    elif not isinstance(data["grafik_verisi"], list):
        data["grafik_verisi"] = [data["grafik_verisi"]]
    
    defaults = {
        "unite": "Veri Analizi",
        "konu_alt_basligi": "",
        "kazanim": "",
        "soru_tipi": "",
        "bloom": "",
        "bloom_ordinal": 0,
        "zorluk": zorluk,
        "gorsel_turu": "",
        "veri_yapisi": "",
        "on_bilgi": [],
        "matematiksel_beceriler": [],
        "kaynak_yil": 2024,
        "image_path": None
    }
    
    for key, default_value in defaults.items():
        if key not in data["metadata"] or data["metadata"][key] is None:
            data["metadata"][key] = default_value
    
    # Ensure on_bilgi and matematiksel_beceriler are lists
    if isinstance(data["metadata"].get("on_bilgi"), str):
        data["metadata"]["on_bilgi"] = [data["metadata"]["on_bilgi"]]
    
    if isinstance(data["metadata"].get("matematiksel_beceriler"), str):
        data["metadata"]["matematiksel_beceriler"] = [data["metadata"]["matematiksel_beceriler"]]
    
    return data

