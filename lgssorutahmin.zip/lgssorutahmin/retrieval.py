"""
Retrieval Module
Builds queries and retrieves relevant examples from vector store
"""
import logging
from typing import List, Dict, Any, Optional

from config import ALLOWED_UNITE, ZORLUK_REVERSE, DEFAULT_TOP_K
from vector_store import get_vector_store, VectorStore

logger = logging.getLogger(__name__)


def build_query_filter(
    zorluk: str,
    unite: Optional[str] = None,
    konu_alt_basligi: Optional[str] = None,
    soru_tipi: Optional[str] = None,
    use_image: bool = False
) -> Dict[str, Any]:
    """
    Build ChromaDB metadata filter based on request parameters
    
    Args:
        zorluk: Difficulty category (kolay, orta, zor)
        unite: Optional unit filter (defaults to Veri Analizi)
        konu_alt_basligi: Optional sub-topic filter
        soru_tipi: Optional question type filter
        use_image: If True, prefer examples with images
        
    Returns:
        ChromaDB where filter dict
    """
    conditions = []
    
    # Always filter by zorluk category
    conditions.append({"zorluk_kategori": {"$eq": zorluk}})
    
    # Always enforce Veri Analizi domain
    target_unite = unite if unite else ALLOWED_UNITE
    conditions.append({"unite": {"$eq": target_unite}})
    
    # Optional filters
    if konu_alt_basligi:
        conditions.append({"konu_alt_basligi": {"$eq": konu_alt_basligi}})
    
    if soru_tipi:
        conditions.append({"soru_tipi": {"$eq": soru_tipi}})
    
    if use_image:
        conditions.append({"has_image": {"$eq": True}})
    
    # Combine with $and
    if len(conditions) == 1:
        return conditions[0]
    else:
        return {"$and": conditions}


def build_query_text(zorluk: str, konu_alt_basligi: Optional[str] = None) -> str:
    """
    Build query text for semantic search
    
    Args:
        zorluk: Difficulty level
        konu_alt_basligi: Optional sub-topic
        
    Returns:
        Query text for embedding
    """
    parts = ["Veri Analizi"]
    
    if konu_alt_basligi:
        parts.append(konu_alt_basligi)
    
    # Add difficulty-related terms
    if zorluk == "kolay":
        parts.extend(["basit grafik okuma", "tek adım", "doğrudan veri okuma"])
    elif zorluk == "orta":
        parts.extend(["karşılaştırma", "oran hesaplama", "iki adım"])
    elif zorluk == "zor":
        parts.extend(["çok adımlı", "çıkarım", "karmaşık analiz"])
    
    return " ".join(parts)


def retrieve(
    zorluk: str,
    unite: Optional[str] = None,
    konu_alt_basligi: Optional[str] = None,
    soru_tipi: Optional[str] = None,
    use_image: bool = False,
    top_k: int = DEFAULT_TOP_K,
    vector_store: Optional[VectorStore] = None
) -> List[Dict[str, Any]]:
    """
    Retrieve relevant examples from vector store
    
    Args:
        zorluk: Difficulty category (kolay, orta, zor)
        unite: Optional unit filter
        konu_alt_basligi: Optional sub-topic filter
        soru_tipi: Optional question type filter
        use_image: If True, prefer examples with images
        top_k: Number of results to retrieve
        vector_store: Optional VectorStore instance
        
    Returns:
        List of retrieved examples with metadata
    """
    vs = vector_store or get_vector_store()
    
    # Build filter
    where_filter = build_query_filter(
        zorluk=zorluk,
        unite=unite,
        konu_alt_basligi=konu_alt_basligi,
        soru_tipi=soru_tipi,
        use_image=use_image
    )
    
    # Build query text
    query_text = build_query_text(zorluk, konu_alt_basligi)
    
    logger.info(f"Retrieving with query: '{query_text}', filter: {where_filter}")
    
    # Query vector store
    try:
        results = vs.query(
            query_text=query_text,
            n_results=top_k,
            where=where_filter
        )
    except Exception as e:
        logger.warning(f"Query with full filter failed: {e}. Trying with minimal filter.")
        # Fallback: try with just zorluk filter
        minimal_filter = {"zorluk_kategori": {"$eq": zorluk}}
        results = vs.query(
            query_text=query_text,
            n_results=top_k,
            where=minimal_filter
        )
    
    # Format results
    examples = []
    
    if results and results.get('ids') and results['ids'][0]:
        for i, doc_id in enumerate(results['ids'][0]):
            example = {
                'id': doc_id,
                'document': results['documents'][0][i] if results.get('documents') else '',
                'metadata': results['metadatas'][0][i] if results.get('metadatas') else {},
                'distance': results['distances'][0][i] if results.get('distances') else 0.0
            }
            examples.append(example)
    
    logger.info(f"Retrieved {len(examples)} examples")
    
    return examples


def format_examples_for_prompt(examples: List[Dict[str, Any]]) -> str:
    """
    Format retrieved examples for inclusion in the prompt
    
    Args:
        examples: List of retrieved examples
        
    Returns:
        Formatted string for prompt
    """
    if not examples:
        return "Örnek soru bulunamadı."
    
    formatted = []
    
    for i, ex in enumerate(examples, 1):
        meta = ex.get('metadata', {})
        
        example_text = f"""
### Örnek {i}
- Konu: {meta.get('konu_alt_basligi', 'Belirtilmemiş')}
- Soru Tipi: {meta.get('soru_tipi', 'Belirtilmemiş')}
- Bloom Seviyesi: {meta.get('bloom', 'Belirtilmemiş')}
- Görsel Türü: {meta.get('gorsel_turu', 'Yok')}
- Veri Yapısı: {meta.get('veri_yapisi', 'Belirtilmemiş')}
- Bağlam: {meta.get('baglam', 'Belirtilmemiş')}
- Kazanım: {meta.get('kazanim', 'Belirtilmemiş')}
- Ön Bilgi: {meta.get('on_bilgi', 'Belirtilmemiş')}
- Matematiksel Beceriler: {meta.get('matematiksel_beceriler', 'Belirtilmemiş')}
"""
        formatted.append(example_text.strip())
    
    return "\n\n".join(formatted)
