// LGS Soru Üretici - Frontend JavaScript

const API_URL = '/generate';
let lastDifficulty = 'orta';
let currentQuestion = null;
let chartInstances = []; // Store chart instances for cleanup
let answered = false; // Track if user has answered

// DOM Elements
const loading = document.getElementById('loading');
const error = document.getElementById('error');
const errorText = document.getElementById('error-text');
const questionSection = document.getElementById('question-section');
const chartsContainer = document.getElementById('charts-container');

// Chart.js color palette
const CHART_COLORS = [
    'rgba(99, 102, 241, 0.8)',   // Primary purple
    'rgba(16, 185, 129, 0.8)',   // Success green
    'rgba(245, 158, 11, 0.8)',   // Warning orange
    'rgba(239, 68, 68, 0.8)',    // Danger red
    'rgba(59, 130, 246, 0.8)',   // Blue
    'rgba(168, 85, 247, 0.8)',   // Purple
    'rgba(236, 72, 153, 0.8)',   // Pink
    'rgba(20, 184, 166, 0.8)',   // Teal
];

const CHART_BORDER_COLORS = [
    'rgba(99, 102, 241, 1)',
    'rgba(16, 185, 129, 1)',
    'rgba(245, 158, 11, 1)',
    'rgba(239, 68, 68, 1)',
    'rgba(59, 130, 246, 1)',
    'rgba(168, 85, 247, 1)',
    'rgba(236, 72, 153, 1)',
    'rgba(20, 184, 166, 1)',
];

// Generate question
async function generateQuestion(difficulty) {
    lastDifficulty = difficulty;

    // Update button states
    document.querySelectorAll('.difficulty-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.difficulty === difficulty) {
            btn.classList.add('active');
        }
    });

    // Show loading
    showLoading();

    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                zorluk: difficulty,
                top_k: 8
            })
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || 'Soru üretilirken bir hata oluştu');
        }

        const data = await response.json();
        currentQuestion = data;
        displayQuestion(data, difficulty);

    } catch (err) {
        showError(err.message);
    }
}

// Display question with charts
function displayQuestion(data, difficulty) {
    hideLoading();
    hideError();

    // Update badge
    const badge = document.getElementById('difficulty-badge');
    badge.textContent = difficulty.toUpperCase();
    badge.className = 'question-badge ' + difficulty;

    // Update topic
    const topic = document.getElementById('question-topic');
    topic.textContent = data.metadata?.konu_alt_basligi || 'Veri Analizi';

    // Render charts
    renderCharts(data.grafik_verisi || []);

    // Update question text
    document.getElementById('question-text').innerHTML = formatText(data.soru);

    // Update options
    document.getElementById('option-a-text').textContent = data.secenekler?.A || '';
    document.getElementById('option-b-text').textContent = data.secenekler?.B || '';
    document.getElementById('option-c-text').textContent = data.secenekler?.C || '';
    document.getElementById('option-d-text').textContent = data.secenekler?.D || '';

    // Reset option styles and answered state
    answered = false;
    document.querySelectorAll('.option').forEach(opt => {
        opt.classList.remove('correct', 'wrong', 'disabled');
    });

    // Update correct answer
    document.getElementById('correct-answer').textContent = data.dogru_cevap;

    // Update explanation
    document.getElementById('explanation-text').textContent = data.aciklama || '';

    // Update metadata
    document.getElementById('meta-konu').textContent = data.metadata?.konu_alt_basligi || '-';
    document.getElementById('meta-soru-tipi').textContent = data.metadata?.soru_tipi || '-';
    document.getElementById('meta-bloom').textContent = data.metadata?.bloom || '-';
    document.getElementById('meta-gorsel').textContent = data.metadata?.gorsel_turu || '-';

    // Reset answer visibility
    const answerContent = document.getElementById('answer-content');
    const showAnswerBtn = document.getElementById('show-answer-btn');
    answerContent.classList.add('hidden');
    showAnswerBtn.classList.remove('open');

    // Show answer section
    document.getElementById('answer-section').classList.remove('hidden');

    // Show question section
    questionSection.classList.remove('hidden');

    // Scroll to question
    questionSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Render charts using Chart.js
function renderCharts(chartDataArray) {
    console.log('renderCharts called with:', chartDataArray);

    // Clear existing charts
    chartInstances.forEach(chart => chart.destroy());
    chartInstances = [];
    chartsContainer.innerHTML = '';

    if (!chartDataArray || chartDataArray.length === 0) {
        console.log('No chart data to render');
        return;
    }

    console.log('Rendering', chartDataArray.length, 'charts');

    chartDataArray.forEach((chartData, index) => {
        const wrapper = document.createElement('div');
        wrapper.className = 'chart-wrapper';

        const title = document.createElement('div');
        title.className = 'chart-title';
        title.textContent = chartData.baslik || `Grafik ${index + 1}`;

        const canvasContainer = document.createElement('div');
        canvasContainer.className = 'chart-canvas-container';

        const canvas = document.createElement('canvas');
        canvas.id = `chart-${index}`;

        canvasContainer.appendChild(canvas);
        wrapper.appendChild(title);
        wrapper.appendChild(canvasContainer);
        chartsContainer.appendChild(wrapper);

        // Create chart
        const chart = createChart(canvas, chartData);
        if (chart) {
            chartInstances.push(chart);
        }
    });
}

// Create a Chart.js chart based on type
function createChart(canvas, chartData) {
    const ctx = canvas.getContext('2d');
    const labels = chartData.etiketler || [];
    const values = chartData.degerler || [];
    const birim = chartData.birim || '';

    // Determine chart type
    let chartType = 'bar';
    if (chartData.tip === 'daire' || chartData.tip === 'pasta') {
        chartType = 'pie';
    } else if (chartData.tip === 'cizgi' || chartData.tip === 'çizgi') {
        chartType = 'line';
    } else if (chartData.tip === 'sutun' || chartData.tip === 'sütun') {
        chartType = 'bar';
    }

    const config = {
        type: chartType,
        data: {
            labels: labels,
            datasets: [{
                data: values,
                backgroundColor: CHART_COLORS.slice(0, labels.length),
                borderColor: CHART_BORDER_COLORS.slice(0, labels.length),
                borderWidth: 2,
                label: birim || 'Değer'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: chartType === 'pie',
                    position: 'bottom',
                    labels: {
                        color: '#f8fafc',
                        font: {
                            family: 'Inter',
                            size: 11
                        },
                        padding: 15
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function (context) {
                            let label = context.label || '';
                            let value = context.parsed.y ?? context.parsed;
                            if (chartType === 'pie') {
                                value = context.parsed;
                            }
                            return `${label}: ${value} ${birim}`;
                        }
                    }
                }
            },
            scales: chartType !== 'pie' ? {
                x: {
                    ticks: {
                        color: '#94a3b8',
                        font: {
                            family: 'Inter'
                        }
                    },
                    grid: {
                        color: 'rgba(148, 163, 184, 0.1)'
                    }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#94a3b8',
                        font: {
                            family: 'Inter'
                        },
                        callback: function (value) {
                            return value + (birim ? ' ' + birim : '');
                        }
                    },
                    grid: {
                        color: 'rgba(148, 163, 184, 0.1)'
                    }
                }
            } : undefined
        }
    };

    return new Chart(ctx, config);
}

// Format text with basic markdown-like styling
function formatText(text) {
    if (!text) return '';

    // Convert markdown tables to HTML
    let formatted = text;

    // Handle tables
    const tableRegex = /\|(.+)\|\n\|[-\s|]+\|\n((?:\|.+\|\n?)+)/g;
    formatted = formatted.replace(tableRegex, (match, headerRow, bodyRows) => {
        const headers = headerRow.split('|').filter(h => h.trim());
        const rows = bodyRows.trim().split('\n').map(row =>
            row.split('|').filter(c => c.trim())
        );

        let table = '<table class="data-table"><thead><tr>';
        headers.forEach(h => {
            table += `<th>${h.trim()}</th>`;
        });
        table += '</tr></thead><tbody>';
        rows.forEach(row => {
            table += '<tr>';
            row.forEach(cell => {
                table += `<td>${cell.trim()}</td>`;
            });
            table += '</tr>';
        });
        table += '</tbody></table>';
        return table;
    });

    // Handle line breaks
    formatted = formatted.replace(/\n/g, '<br>');

    return formatted;
}

// Toggle answer visibility
function toggleAnswer() {
    const answerContent = document.getElementById('answer-content');
    const showAnswerBtn = document.getElementById('show-answer-btn');

    if (answerContent.classList.contains('hidden')) {
        answerContent.classList.remove('hidden');
        showAnswerBtn.classList.add('open');

        // Highlight correct option
        const correctAnswer = document.getElementById('correct-answer').textContent;
        const optionId = 'option-' + correctAnswer.toLowerCase();
        document.getElementById(optionId)?.classList.add('correct');
    } else {
        answerContent.classList.add('hidden');
        showAnswerBtn.classList.remove('open');

        // Remove highlight
        document.querySelectorAll('.option').forEach(opt => {
            opt.classList.remove('correct');
        });
    }
}

// Generate new question with same difficulty
function generateNewQuestion() {
    generateQuestion(lastDifficulty);
}

// Check if selected answer is correct
function checkAnswer(selectedLetter) {
    if (answered || !currentQuestion) return;

    answered = true;
    const correctAnswer = currentQuestion.dogru_cevap;
    const selectedOption = document.getElementById('option-' + selectedLetter.toLowerCase());
    const correctOption = document.getElementById('option-' + correctAnswer.toLowerCase());

    // Disable all options
    document.querySelectorAll('.option').forEach(opt => {
        opt.classList.add('disabled');
    });

    if (selectedLetter === correctAnswer) {
        // Correct answer
        selectedOption.classList.add('correct');
    } else {
        // Wrong answer - show selected as wrong and correct as green
        selectedOption.classList.add('wrong');
        correctOption.classList.add('correct');
    }

    // Auto-show explanation after answering
    const answerContent = document.getElementById('answer-content');
    const showAnswerBtn = document.getElementById('show-answer-btn');
    if (answerContent.classList.contains('hidden')) {
        answerContent.classList.remove('hidden');
        showAnswerBtn.classList.add('open');
    }
}

// Retry last request
function retryLastRequest() {
    generateQuestion(lastDifficulty);
}

// Show/hide loading
function showLoading() {
    loading.classList.remove('hidden');
    error.classList.add('hidden');
    questionSection.classList.add('hidden');
}

function hideLoading() {
    loading.classList.add('hidden');
}

// Show/hide error
function showError(message) {
    hideLoading();
    errorText.textContent = message;
    error.classList.remove('hidden');
    questionSection.classList.add('hidden');
}

function hideError() {
    error.classList.add('hidden');
}

// Add CSS for tables dynamically
const tableStyles = document.createElement('style');
tableStyles.textContent = `
    .data-table {
        width: 100%;
        border-collapse: collapse;
        margin: 1rem 0;
        background: var(--bg-card-hover);
        border-radius: 8px;
        overflow: hidden;
    }
    .data-table th,
    .data-table td {
        padding: 0.75rem 1rem;
        text-align: left;
        border-bottom: 1px solid var(--border);
    }
    .data-table th {
        background: rgba(99, 102, 241, 0.2);
        font-weight: 600;
        color: var(--primary-light);
    }
    .data-table tr:last-child td {
        border-bottom: none;
    }
    .data-table tr:hover td {
        background: rgba(99, 102, 241, 0.05);
    }
`;
document.head.appendChild(tableStyles);
