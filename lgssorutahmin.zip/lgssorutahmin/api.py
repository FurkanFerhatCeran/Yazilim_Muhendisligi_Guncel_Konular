"""
FastAPI Application
REST API for LGS question generation
"""
import logging
from typing import Optional
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

from config import ALLOWED_UNITE, DEFAULT_TOP_K, BASE_DIR
from utils import setup_logging
from vector_store import get_vector_store
from generator import generate_question

# Setup logging
setup_logging()
logger = logging.getLogger(__name__)


# Request/Response models
class GenerateRequest(BaseModel):
    """Request model for question generation"""
    zorluk: str = Field(
        ...,
        description="Zorluk seviyesi: kolay, orta, veya zor",
        pattern="^(kolay|orta|zor)$"
    )
    unite: Optional[str] = Field(
        default=None,
        description="Ünite filtresi (varsayılan: Veri Analizi)"
    )
    konu_alt_basligi: Optional[str] = Field(
        default=None,
        description="Alt konu başlığı filtresi"
    )
    soru_tipi: Optional[str] = Field(
        default=None,
        description="Soru tipi filtresi"
    )
    use_image: Optional[bool] = Field(
        default=False,
        description="Görsel içeren örnekleri tercih et"
    )
    top_k: Optional[int] = Field(
        default=DEFAULT_TOP_K,
        ge=1,
        le=20,
        description="Alınacak örnek sayısı (1-20)"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "zorluk": "orta",
                "unite": None,
                "konu_alt_basligi": None,
                "soru_tipi": None,
                "use_image": False,
                "top_k": 8
            }
        }


class HealthResponse(BaseModel):
    """Health check response"""
    status: str
    message: str
    index_count: int


# Lifespan handler
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler"""
    # Startup
    logger.info("Starting LGS RAG API...")
    
    # Try to load vector store
    try:
        vs = get_vector_store()
        if vs.load_index():
            count = vs.get_collection_count()
            logger.info(f"Vector store loaded with {count} documents")
        else:
            logger.warning("Vector store not found. Run 'python vector_store.py' to build index.")
    except Exception as e:
        logger.warning(f"Could not load vector store: {e}")
    
    yield
    
    # Shutdown
    logger.info("Shutting down LGS RAG API...")


# Create FastAPI app
app = FastAPI(
    title="LGS Veri Analizi Soru Üretici",
    description="RAG tabanlı LGS matematik sorusu üretim API'si",
    version="1.0.0",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
static_dir = BASE_DIR / "static"
templates_dir = BASE_DIR / "templates"
if static_dir.exists():
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")


@app.get("/", response_class=HTMLResponse)
async def index():
    """Serve the main HTML page"""
    index_file = templates_dir / "index.html"
    if index_file.exists():
        return HTMLResponse(content=index_file.read_text(encoding="utf-8"))
    return HTMLResponse(content="<h1>LGS Soru Üretici</h1><p>templates/index.html bulunamadı</p>")


@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    try:
        vs = get_vector_store()
        count = vs.get_collection_count()
        return HealthResponse(
            status="healthy",
            message="API is running",
            index_count=count
        )
    except Exception as e:
        return HealthResponse(
            status="degraded",
            message=f"Vector store issue: {str(e)}",
            index_count=0
        )


@app.post("/generate")
async def generate(request: GenerateRequest):
    """
    Generate a new LGS Veri Analizi question
    
    - **zorluk**: Difficulty level (kolay, orta, zor)
    - **unite**: Optional unit filter (defaults to Veri Analizi)
    - **konu_alt_basligi**: Optional sub-topic filter
    - **soru_tipi**: Optional question type filter
    - **use_image**: Prefer examples with images
    - **top_k**: Number of examples to retrieve
    """
    logger.info(f"Generate request: {request.model_dump()}")
    
    # Validate zorluk
    if request.zorluk not in ["kolay", "orta", "zor"]:
        raise HTTPException(
            status_code=400,
            detail="zorluk must be one of: kolay, orta, zor"
        )
    
    # Enforce Veri Analizi domain
    unite = request.unite if request.unite else ALLOWED_UNITE
    if unite != ALLOWED_UNITE:
        logger.warning(f"Requested unite '{unite}' overridden to '{ALLOWED_UNITE}'")
        unite = ALLOWED_UNITE
    
    try:
        result = generate_question(
            zorluk=request.zorluk,
            unite=unite,
            konu_alt_basligi=request.konu_alt_basligi,
            soru_tipi=request.soru_tipi,
            use_image=request.use_image or False,
            top_k=request.top_k or DEFAULT_TOP_K
        )
        
        # Check for generation error
        if result.get("error"):
            raise HTTPException(
                status_code=500,
                detail=result.get("message", "Soru üretimi başarısız oldu")
            )
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Generation error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Soru üretimi sırasında hata oluştu: {str(e)}"
        )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
