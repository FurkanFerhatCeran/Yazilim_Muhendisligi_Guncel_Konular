"""
Prompt Templates for LGS Question Generation
Difficulty-specific prompts for the RAG system
"""

# Difficulty rules to inject into prompts
DIFFICULTY_RULES = {
    "kolay": """
## Zorluk: KOLAY (Seviye 1-2)
Bu zorluk seviyesi için şu kurallara uy:
- Tek adımlık, doğrudan grafik/tablo okuma sorusu olmalı
- Düşük çıkarım gerektirmeli, veri doğrudan okunabilmeli
- Küçük tam sayılar kullan (1-100 arası)
- Basit sütun veya daire grafiği tercih et
- Toplama veya çıkarma gibi temel işlemler yeterli
- "Aşağıdakilerden hangisi doğrudur?" tarzı basit sorular
""",
    
    "orta": """
## Zorluk: ORTA (Seviye 3)
Bu zorluk seviyesi için şu kurallara uy:
- İki adımlık hesaplama veya karşılaştırma gerektirmeli
- Temel oran-orantı veya yüzde hesaplama içerebilir
- Toplam, fark veya basit oran bulma soruları
- Birden fazla veri setini karşılaştırma gerektirebilir
- Grafik türleri arası basit dönüşümler olabilir
- Orta düzey sayısal değerler (10-500 arası)
""",
    
    "zor": """
## Zorluk: ZOR (Seviye 4-5)
Bu zorluk seviyesi için şu kurallara uy:
- Çok adımlı akıl yürütme ve çıkarım gerektirmeli
- "Aşağıdakilerden hangisi çıkarılamaz?" veya "Kesinlikle yanlıştır" tarzı sorular
- Birden fazla grafik/tablo arasında ilişki kurma
- Karmaşık oran-orantı veya yüzde değişimi hesaplama
- Eksik veri tamamlama veya tersine mühendislik
- Yüksek bilişsel beceri gerektiren analiz ve değerlendirme
"""
}

# Base system prompt
SYSTEM_PROMPT = """Sen LGS (Lise Geçiş Sınavı) düzeyinde Türkçe matematik soruları üreten uzman bir eğitimcisin.
Sadece "Veri Analizi" ünitesinden soru üreteceksin.

## Temel Kurallar:
1. Soru Türkçe olmalı
2. Tam olarak 4 seçenek (A, B, C, D) olmalı
3. Sadece 1 doğru cevap olmalı
4. Çeldiriciler mantıklı ve inandırıcı olmalı
5. Kısa ve öz bir açıklama ekle
6. LGS müfredatına uygun ol
7. **ZORUNLU: Her soruda grafik_verisi alanı MUTLAKA doldurulmalı!**

## Veri Analizi Konuları:
- Sütun grafikleri
- Çizgi grafikleri  
- Daire grafikleri
- Tablo yorumlama
- Grafik türleri arası dönüşüm
- Oran ve yüzde hesaplama
- Veri karşılaştırma

## ÖNEMLİ: GRAFİK VERİSİ ZORUNLUDUR!
- Her soru için grafik_verisi dizisi MUTLAKA en az 1 grafik içermeli
- Grafik verileri soru metninde YAZILMAMALI, sadece grafik_verisi alanında verilmeli
- Soru metni "Aşağıdaki grafiğe göre..." gibi ifadelerle başlamalı
"""

# Output format instruction
OUTPUT_FORMAT = """
## Çıktı Formatı
Yanıtını SADECE aşağıdaki JSON formatında ver, başka hiçbir metin ekleme:

```json
{
  "soru": "Soru metni buraya... (Grafik verilerini metin olarak YAZMA, sadece soruyu sor)",
  "grafik_verisi": [
    {
      "tip": "daire|sutun|cizgi",
      "baslik": "Grafik başlığı",
      "etiketler": ["Etiket1", "Etiket2", "Etiket3"],
      "degerler": [25, 35, 40],
      "birim": "kişi|adet|%|derece"
    }
  ],
  "secenekler": {
    "A": "Birinci seçenek",
    "B": "İkinci seçenek",
    "C": "Üçüncü seçenek",
    "D": "Dördüncü seçenek"
  },
  "dogru_cevap": "A",
  "aciklama": "Kısa çözüm açıklaması...",
  "metadata": {
    "unite": "Veri Analizi",
    "konu_alt_basligi": "Alt konu başlığı",
    "kazanim": "İlgili kazanım",
    "soru_tipi": "Soru tipi",
    "bloom": "Bloom taksonomisi seviyesi",
    "bloom_ordinal": 3,
    "zorluk": "kolay|orta|zor",
    "gorsel_turu": "Grafik türü veya Yok",
    "veri_yapisi": "Veri yapısı açıklaması",
    "on_bilgi": ["Gerekli ön bilgiler"],
    "matematiksel_beceriler": ["Gerekli beceriler"],
    "kaynak_yil": 2024,
    "image_path": null
  }
}
```

## GRAFİK VERİSİ KURALLARI:
- Her soru için EN AZ 1 grafik verisi olmalı
- tip: "daire" (pasta grafiği), "sutun" (bar chart), veya "cizgi" (line chart)
- etiketler ve degerler dizileri aynı uzunlukta olmalı
- Daire grafiklerinde toplam 100 veya 360 olabilir
- Soru metninde grafik verilerini YAZMA, frontend otomatik çizecek
"""

# Correction prompt for retry
CORRECTION_PROMPT = """
Önceki yanıtın geçerli JSON formatında değildi veya eksik alanlar içeriyordu.
Lütfen aşağıdaki kurallara dikkat ederek tekrar dene:

1. Yanıt SADECE JSON olmalı, başka metin olmamalı
2. Tüm alanlar doldurulmalı
3. secenekler tam olarak A, B, C, D anahtarlarını içermeli
4. dogru_cevap sadece A, B, C veya D olmalı
5. dogru_cevap, secenekler içindeki bir anahtarla eşleşmeli

Şimdi düzeltilmiş JSON yanıtını ver:
"""


def build_generation_prompt(
    zorluk: str,
    examples_text: str,
    additional_context: str = ""
) -> str:
    """
    Build the full generation prompt
    
    Args:
        zorluk: Difficulty level (kolay, orta, zor)
        examples_text: Formatted retrieved examples
        additional_context: Any additional context to include
        
    Returns:
        Complete prompt string
    """
    difficulty_rules = DIFFICULTY_RULES.get(zorluk, DIFFICULTY_RULES["orta"])
    
    prompt = f"""{SYSTEM_PROMPT}

{difficulty_rules}

## Referans Örnekler (KOPYALAMA, sadece stil referansı olarak kullan):
{examples_text}

{additional_context}

## Görev
Yukarıdaki örneklere benzer tarzda, belirtilen zorluk seviyesinde YENİ ve ORİJİNAL bir soru üret.
Örnekleri birebir kopyalama, sadece stil ve format referansı olarak kullan.
{OUTPUT_FORMAT}
"""
    
    return prompt


def build_correction_prompt(original_response: str, error_message: str) -> str:
    """
    Build a correction prompt for retry
    
    Args:
        original_response: The invalid response from first attempt
        error_message: Description of what was wrong
        
    Returns:
        Correction prompt
    """
    return f"""
{CORRECTION_PROMPT}

Hata: {error_message}

Orijinal (hatalı) yanıt:
{original_response[:500]}...

Lütfen düzeltilmiş ve geçerli JSON formatında yanıt ver:
"""
