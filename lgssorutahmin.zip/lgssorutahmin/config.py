"""
Configuration for LGS RAG System
Environment variables and default settings
"""
import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env file if exists
load_dotenv()

# Base paths
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR
CHROMA_PERSIST_DIR = BASE_DIR / "chroma_db"

# Gemini API Configuration
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
GEMINI_EMBED_MODEL = os.getenv("GEMINI_EMBED_MODEL", "text-embedding-004")

# Dataset Configuration
DATASET_PATH = DATA_DIR / "veri_analizi_300_soru_fe.csv"

# RAG Configuration
DEFAULT_TOP_K = 8
MAX_RETRIES = 3

# Difficulty mapping: numeric zorluk (1-5) to category
ZORLUK_MAPPING = {
    1: "kolay",
    2: "kolay", 
    3: "orta",
    4: "zor",
    5: "zor"
}

# Reverse mapping for filtering
ZORLUK_REVERSE = {
    "kolay": [1, 2],
    "orta": [3],
    "zor": [4, 5]
}

# Domain enforcement
ALLOWED_UNITE = "Veri Analizi"

# Embedding configuration
EMBEDDING_BATCH_SIZE = 100
EMBEDDING_DIMENSION = 768

# LLM Configuration
LLM_TEMPERATURE = 0.7
LLM_MAX_TOKENS = 8192
