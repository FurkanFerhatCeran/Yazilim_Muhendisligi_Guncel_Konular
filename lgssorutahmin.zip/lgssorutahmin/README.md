# LGS Veri Analizi Soru Üretici (RAG Sistemi)

LGS (Lise Geçiş Sınavı) düzeyinde Türkçe "Veri Analizi" matematik soruları üreten RAG (Retrieval-Augmented Generation) sistemi.

## Özellikler

- ✅ Google Gemini LLM ile Türkçe soru üretimi
- ✅ ChromaDB ile vektör tabanlı örnek soru arama
- ✅ Zorluk seviyesine göre filtreleme (kolay, orta, zor)
- ✅ Metadata tabanlı gelişmiş filtreleme
- ✅ FastAPI REST API
- ✅ JSON çıktı validasyonu ve retry mekanizması

## Kurulum

### 1. Bağımlılıkları Yükle

```bash
cd c:\Users\Zehra\OneDrive\Masaüstü\lgssorutahmin
pip install -r requirements.txt
```

### 2. Ortam Değişkenlerini Ayarla

`.env` dosyası oluştur:

```env
GEMINI_API_KEY=your-gemini-api-key-here
GEMINI_MODEL=gemini-1.5-flash
GEMINI_EMBED_MODEL=text-embedding-004
```

Veya PowerShell'de:

```powershell
$env:GEMINI_API_KEY="your-gemini-api-key-here"
```

### 3. Vektör İndeksini Oluştur

```bash
python vector_store.py
```

Bu komut CSV dosyasından ~300 soruyu yükleyip ChromaDB'ye indeksler.

### 4. API'yi Başlat

```bash
uvicorn api:app --reload --port 8000
```

API şu adreste çalışacak: http://localhost:8000

## API Kullanımı

### Soru Üret

```bash
# Orta zorlukta soru üret
curl -X POST http://localhost:8000/generate \
  -H "Content-Type: application/json" \
  -d '{"zorluk": "orta"}'

# Kolay zorlukta soru üret
curl -X POST http://localhost:8000/generate \
  -H "Content-Type: application/json" \
  -d '{"zorluk": "kolay"}'

# Zor zorlukta, görsel içeren örneklerle
curl -X POST http://localhost:8000/generate \
  -H "Content-Type: application/json" \
  -d '{"zorluk": "zor", "use_image": true, "top_k": 10}'
```

### PowerShell ile Test

```powershell
$body = @{zorluk = "orta"} | ConvertTo-Json
Invoke-RestMethod -Uri "http://localhost:8000/generate" -Method Post -Body $body -ContentType "application/json"
```

### Sağlık Kontrolü

```bash
curl http://localhost:8000/health
```

## Çıktı Formatı

```json
{
  "soru": "Aşağıdaki sütun grafiğinde...",
  "secenekler": {
    "A": "24",
    "B": "36",
    "C": "48",
    "D": "60"
  },
  "dogru_cevap": "B",
  "aciklama": "Grafikte verilen değerler toplanarak...",
  "metadata": {
    "unite": "Veri Analizi",
    "konu_alt_basligi": "Sütun Grafik Yorumlama",
    "kazanim": "Sütun grafiğindeki verileri yorumlar",
    "soru_tipi": "Veri Yorumlama",
    "bloom": "Analiz",
    "bloom_ordinal": 3,
    "zorluk": "orta",
    "gorsel_turu": "Sütun Grafik",
    "veri_yapisi": "Sayısal veri",
    "on_bilgi": ["Grafik okuma", "Toplama"],
    "matematiksel_beceriler": ["Veri analizi", "Hesaplama"],
    "kaynak_yil": 2024,
    "image_path": null
  }
}
```

## Dosya Yapısı

```
lgssorutahmin/
├── config.py              # Ortam değişkenleri ve ayarlar
├── embedder.py            # Gemini embedding istemcisi
├── llm_client.py          # Gemini LLM istemcisi
├── data_loader.py         # CSV yükleme ve normalizasyon
├── vector_store.py        # ChromaDB entegrasyonu
├── retrieval.py           # Sorgu oluşturucu ve filtreler
├── prompt_templates.py    # Zorluk bazlı prompt şablonları
├── generator.py           # RAG montajı ve validasyon
├── utils.py               # JSON şema validasyonu
├── api.py                 # FastAPI endpoint
├── requirements.txt       # Bağımlılıklar
├── .env                   # Ortam değişkenleri (oluşturmanız gerekir)
├── veri_analizi_300_soru_fe.csv  # Veri seti
└── chroma_db/             # ChromaDB persist dizini (otomatik oluşur)
```

## Zorluk Seviyeleri

| Seviye | CSV Değeri | Açıklama |
|--------|------------|----------|
| kolay  | 1-2        | Tek adım, doğrudan veri okuma |
| orta   | 3          | İki adım, karşılaştırma, temel oran |
| zor    | 4-5        | Çok adım, çıkarım, karmaşık analiz |

## Notlar

- Gemini API anahtarı için [Google AI Studio](https://aistudio.google.com/apikey) adresinden alabilirsiniz
- İlk çalıştırmada vektör indeksi oluşturulması birkaç dakika sürebilir
- API doğrulaması başarısız olursa otomatik olarak 2 kez yeniden dener
